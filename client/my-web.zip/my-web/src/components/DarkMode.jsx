import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

const DarkMode = () => {
  const getInitialTheme = () => {
    if (typeof window !== "undefined") {
      const storedTheme = localStorage.getItem("theme");
      if (storedTheme) {
        return storedTheme === "dark";
      }
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return false;
  };

  const [darkMode, setDarkMode] = useState(getInitialTheme());

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
    console.log("HTML class list:", document.documentElement.classList); // Debugging
  }, [darkMode]);

  return (
    <div>
      <button
        onClick={() => setDarkMode(!darkMode)}
        className="p-2 rounded-full  hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer transition duration-300"
      >
        {darkMode ? (
          <Moon className="text-white" />
        ) : (
          <Sun className="text-yellow-500" />
        )}
      </button>
    </div>
  );
};

export default DarkMode;
