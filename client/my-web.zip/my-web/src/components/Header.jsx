import React, { useState, useEffect, useCallback } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import { useTranslation } from "react-i18next";
import DarkMode from "../components/DarkMode.jsx";
import img9 from "../assets/images/schoolImages/9.jpg";
import { Link, useLocation } from "react-router-dom";
import LanguageSwitcher from "./LanguageSwitcher.jsx";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(
    localStorage.getItem("theme") === "dark"
  );
  const [language, setLanguage] = useState(
    localStorage.getItem("language") || "kh"
  );
  const [isVisible, setIsVisible] = useState(true);
  const { t } = useTranslation();
  const location = useLocation(); // For active link styling

  useEffect(() => {
    if (typeof window !== "undefined") {
      AOS.init({ duration: 1000 });
    }
  }, []);



  const toggleMenu = useCallback(() => {
    setIsMenuOpen((prev) => !prev);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setIsDarkMode((prevMode) => {
      const newMode = !prevMode;
      localStorage.setItem("theme", newMode ? "dark" : "light");
      return newMode;
    });
  }, []);

  const switchLanguage = useCallback((newLang) => {
    setLanguage(newLang);
    localStorage.setItem("language", newLang);
  }, []);

  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark");
      document.body.classList.remove("light");
    } else {
      document.body.classList.add("light");
      document.body.classList.remove("dark");
    }
  }, [isDarkMode]);

  return (
    <div
      className="relative w-full h-screen bg-cover bg-center transition-colors duration-300"
      style={{ backgroundImage: `url(${img9})` }}
    >
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent"></div>

      {/* Navbar */}
      <nav className="absolute top-0 left-0 w-full flex justify-between items-center p-6">
        <h1 className="text-white text-3xl font-bold">MySchool</h1>

        {/* Navbar Links */}
        <ul className="hidden md:flex space-x-4 text-white z-90">
          {[{ to: "/", label: t("home") },
          { to: "/news#news", label: t("news") },
          { to: "/about#about", label: t("about_us") },
          { to: "/extras#extras", label: t("extras") },
          { to: "/contact#contact", label: t("contact_us") },
          { to: "/test", label: t("Test") },
          ].map(({ to, label }) => (
            <Link
              key={to}
              to={to}
              className={`text-center text-sm sm:text-xs md:text-lg lg:text-lg font-bold lang-text px-4 py-2 rounded-full transition duration-300 ${location.pathname === to
                  ? "bg-secondary text-white dark:text-white"
                  : "hover:text-gray-900 dark:hover:text-white"
                }`}
            >
              {label}
            </Link>
          ))}
        </ul>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-white"
          onClick={toggleMenu}
        >
          {isMenuOpen ? "Close" : "Menu"}
        </button>

        {/* Dark Mode and Language Switcher */}
        <div className="flex items-center space-x-4 z-90">
          <DarkMode toggleDarkMode={toggleDarkMode} isDarkMode={isDarkMode} />
          <LanguageSwitcher switchLanguage={switchLanguage} language={language} />
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        className={`md:hidden absolute top-0 left-0 w-full bg-black/50 p-4 transition transform ${isMenuOpen ? "block" : "hidden"
          }`}
      >
        <ul className="flex flex-col items-center space-y-4 text-white">
          {[{ to: "/", label: t("home") },
          { to: "/news#news", label: t("news") },
          { to: "/about#about", label: t("about_us") },
          { to: "/extras#extras", label: t("extras") },
          { to: "/contact#contact", label: t("contact_us") },
          { to: "/test", label: t("Test") },
          ].map(({ to, label }) => (
            <Link
              key={to}
              to={to}
              onClick={toggleMenu}
              className="text-center text-lg font-bold lang-text px-4 py-2 rounded-full"
            >
              {label}
            </Link>
          ))}
        </ul>
      </div>

      {/* Hero Section */}
      <div
        data-aos="fade-up"
        data-aos-duration="1000"
        className="relative z-10 flex flex-col items-center justify-center h-full text-center text-white px-4"
      >
        <h1 className="text-3xl sm:text-5xl font-bold">{t("about_intro")}</h1>
        <p className="text-xl sm:text-3xl mt-4 max-w-2xl">
          {t("about_intor_desc")}
        </p>
        <Link to="/join">
          <button

            className="mt-5 lg:inline-flex items-center border-0 py-2 px-5 focus:outline-none rounded-full bg-primary text-white focus:ring-2 hover:scale-105 transition duration-300"
          >
            {t("joinus")}
          </button>
        </Link>

      </div>
    </div>
  );
};

export default Header;
