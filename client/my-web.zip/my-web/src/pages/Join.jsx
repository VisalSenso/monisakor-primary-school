import { useState } from "react";
import axios from "axios";

const Join = () => {
  const [data, setData] = useState({
    full_name: "",
    gender: "",
    dob: "",
    father_name: "",
    father_job: "",
    mother_name: "",
    mother_job: "",
    place_of_birth: "",
    current_place: "",
    phone: "",
    image: null, // Image upload
  });

  const [formErrors, setFormErrors] = useState({});
  const [loading, setLoading] = useState(false);

  // Handle text field changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setData({ ...data, [name]: value });
  };

  // Handle file input changes
  const handleFileChange = (e) => {
    setData({ ...data, image: e.target.files[0] });
  };

  // Handle form submission using axios
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    // Validate form data
    let errors = {};
    Object.entries(data).forEach(([key, value]) => {
      if (!value && key !== "image") {
        errors[key] = "This field is required";
      }
    });

    if (!data.image) errors.image = "Please upload an image";

    setFormErrors(errors);

    // If there are validation errors, stop the submission
    if (Object.keys(errors).length > 0) {
      setLoading(false);
      return;
    }

    // Prepare FormData
    const formDataToSend = new FormData();
    for (let key in data) {
      formDataToSend.append(key, data[key]);
    }

    try {
      const response = await axios.post(
        "http://localhost/project/monisakor-primary-school/server/api/Join.php",
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      const result = response.data;

      if (response.status === 200) {
        alert("✅ " + result.message);
        setData({
          full_name: "",
          gender: "",
          dob: "",
          father_name: "",
          father_job: "",
          mother_name: "",
          mother_job: "",
          place_of_birth: "",
          current_place: "",
          phone: "",
          image: null,
        });
      } else {
        alert("❌ " + result.error);
      }
    } catch (error) {
      console.error("Error:", error);
      alert("❌ Something went wrong. Try again!");
    }
    setLoading(false);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-4 bg-white p-6 rounded-lg shadow-md"
    >
      {Object.entries(data).map(([key, value]) => (
        <div key={key} className="relative">
          <label
            htmlFor={key}
            className="text-sm font-medium text-gray-800 dark:text-gray-200"
          >
            {key.replace(/_/g, " ").toUpperCase()}
          </label>

          {key === "gender" ? (
            <select
              required
              name={key}
              id={key}
              value={value}
              onChange={handleChange}
              className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
            >
              <option value="">Select Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Others">Others</option>
            </select>
          ) : key === "dob" ? (
            <input
              required
              type="date"
              name={key}
              id={key}
              value={value}
              onChange={handleChange}
              className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
            />
          ) : key === "image" ? (
            <input
              required
              type="file"
              name={key}
              id={key}
              accept="image/*"
              onChange={handleFileChange}
              className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
            />
          ) : (
            <input
              required
              type={key === "phone" ? "tel" : "text"}
              name={key}
              id={key}
              value={value}
              onChange={handleChange}
              className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
            />
          )}

          {formErrors[key] && (
            <p className="text-red-500 text-xs mt-1">{formErrors[key]}</p>
          )}
        </div>
      ))}

      <button
        type="submit"
        className="w-full py-2 px-4 bg-primary text-white font-medium rounded-lg hover:bg-opacity-90 transition"
        disabled={loading}
      >
        {loading ? "Processing..." : "Join"}
      </button>
    </form>
  );
};

export default Join;
