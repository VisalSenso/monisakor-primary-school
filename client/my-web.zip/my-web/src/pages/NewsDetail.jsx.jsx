import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";

const NewsDetail = () => {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const newsId = params.get("id");

  const [newsDetail, setNewsDetail] = useState(null);
  const [recentNews, setRecentNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedNews, setSelectedNews] = useState(null); // State for selected recent news

  useEffect(() => {
    const fetchNewsDetail = async () => {
      try {
        const response = await axios.get(
          `http://localhost:/project/monisakor-primary-school/server/api/getNewsDetail.php?id=${newsId}`
        );
        setNewsDetail(response.data);
      } catch (error) {
        setError("Error fetching news details.");
        console.error("Fetch error:", error);
      } finally {
        setLoading(false);
      }
    };

    const fetchRecentNews = async () => {
      try {
        const response = await axios.get(
          `http://localhost:/project/monisakor-primary-school/server/api/getRecentNews.php`
        );
        setRecentNews(response.data.recentNews); // Correctly accessing recentNews
      } catch (error) {
        console.error("Error fetching recent news:", error);
      }
    };

    if (newsId) {
      fetchNewsDetail();
    }
    fetchRecentNews();
  }, [newsId]);

  const handleRecentNewsClick = async (id) => {
    // Fetch news detail for the clicked recent news
    try {
      const response = await axios.get(
        `http://localhost:/project/monisakor-primary-school/server/api/getNewsDetail.php?id=${id}`
      );
      setSelectedNews(response.data); // Set the selected news details
    } catch (error) {
      console.error("Error fetching selected news:", error);
    }
  };

  if (loading) return <div className="text-center py-4">Loading...</div>;
  if (error || (!newsDetail && !selectedNews))
    return <div className="text-center py-4">{error || "News not found"}</div>;

  const currentNewsDetail = selectedNews || newsDetail;

  return (
    <div className=" container mt-20 flex flex-col md:flex-row mx-auto p-8">
      {/* Left Section (News Detail) */}
      <div className="w-full md:w-2/3 mb-6 md:mb-0">
        <h1 className="text-4xl font-extrabold text-gray-900 leading-tight">
          {currentNewsDetail.about}
        </h1>
        <p className="text-sm text-gray-600 mt-2">
          {currentNewsDetail.time} | {currentNewsDetail.date}
        </p>
        <img
          className="w-full h-96 object-cover mt-6 rounded-lg shadow-lg"
          src={`http://localhost:/project/monisakor-primary-school/assects/images/notices_files/${currentNewsDetail.image_url.replace(
            /^.*[\\\/]/,
            ""
          )}`}
          alt={currentNewsDetail.about}
        />

        <p className="mt-6 text-lg text-gray-800">
          {currentNewsDetail.notice_description}
        </p>
      </div>

      {/* Divider Line */}
      {/* <div className="ml-8 h-fuly w-0.5 bg-gray-300"></div> */}

      {/* Right Section (Recent News) */}
      <div className="w-full md:w-1/3 pl-0 md:pl-8">
        <h2 className="title-font text-3xl sm:text-4xl md:text-4xl mb-4 sm:mb-6 font-extrabold text-primary text-lang leading-tight transition-all duration-300 ease-in-out transform group-hover:scale-105 group-hover:text-secondary dark:hover:text-slate-200">
          Recent News
        </h2>
        <div className="h-1 bg-secondary mt-4 mb-4 "></div>
        <div className="space-y-6">
          {recentNews.length > 0 ? (
            <ul>
              {recentNews.map((news) => (
                <li key={news.id} className="mb-4">
                  <button
                    onClick={() => handleRecentNewsClick(news.id)} // Set the selected news on click
                    className="group flex flex-col w-full text-left p-4 "
                  >
                    <h3 className="text-2xl font-semibold text-gray-900 group-hover:text-blue-600">
                      {news.about}
                    </h3>
                    <p className="text-sm text-gray-600 mt-2">{news.date}</p>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-lg text-gray-500">No recent news available.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default NewsDetail;
