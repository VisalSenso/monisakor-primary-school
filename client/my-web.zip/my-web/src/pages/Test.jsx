import React, { useState, useEffect, useCallback } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import { useTranslation } from "react-i18next";
import DarkMode from "../components/DarkMode.jsx";
import img9 from "../assets/images/schoolImages/9.jpg";
import { Link, useLocation } from "react-router-dom";

const Test = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(
    localStorage.getItem("theme") === "dark"
  );
  const [language, setLanguage] = useState(
    localStorage.getItem("language") || "kh"
  );
  const [isVisible, setIsVisible] = useState(true);
  const { t } = useTranslation();

  useEffect(() => {
    // Initialize AOS (animate on scroll)
    if (typeof window !== "undefined") {
      AOS.init({ duration: 1000 });
    }
  }, []);

  useEffect(() => {
    let lastScrollY = window.scrollY;

    const handleScroll = () => {
      if (window.scrollY > lastScrollY) {
        setIsVisible(false);
      } else {
        setIsVisible(true);
      }
      lastScrollY = window.scrollY;
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const toggleMenu = useCallback(() => {
    setIsMenuOpen((prev) => !prev);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setIsDarkMode((prevMode) => {
      const newMode = !prevMode;
      // Save the theme to localStorage
      localStorage.setItem("theme", newMode ? "dark" : "light");
      return newMode;
    });
  }, []);

  const switchLanguage = useCallback((newLang) => {
    setLanguage(newLang);
    localStorage.setItem("language", newLang);
  }, []);

  // Apply the dark or light theme class to the body element
  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark");
      document.body.classList.remove("light");
    } else {
      document.body.classList.add("light");
      document.body.classList.remove("dark");
    }
  }, [isDarkMode]); // This effect runs when isDarkMode changes

  return (
    <div
      className={`relative w-full h-screen bg-cover bg-center transition-colors duration-300 mt-30 ${isDarkMode ? "dark:bg-gray-900" : ""
        }`}
      style={{ backgroundImage: `url(${img9})` }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent"></div>

      {/* Navbar */}
      <nav className="absolute top-0 left-0 w-full flex justify-between items-center p-6 ">
        <h1 className="text-white text-3xl font-bold">MySchool</h1>
        <ul className="flex space-x-6 text-white z-90">
          {[
            { to: "/", label: t("home") },
            { to: "/news", label: t("news") },
            { to: "/about", label: t("about_us") },
            { to: "/extras", label: t("extras") },
            { to: "/contact", label: t("contact_us") },
            { to: "/test", label: t("Test") },


          ].map(({ to, label }) => (
            <Link
              key={to}
              to={to}
              className={`text-center text-sm sm:text-xs md:text-lg lg:text-lg font-bold lang-text px-4 py-2 rounded-full transition duration-300 ${location.pathname === to
                  ? "bg-secondary text-white dark:text-white"
                  : "hover:text-gray-900 dark:hover:text-white"
                }`}
            >
              {label}
            </Link>
          ))}
        </ul>
        <div className="flex items-center space-x-4 z-90">
          <DarkMode toggleDarkMode={toggleDarkMode} isDarkMode={isDarkMode} />
          <button className="bg-red-600 text-white px-4 py-2 rounded">Login</button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center text-white px-4">
        <h1 className="text-5xl font-bold">Welcome to MySchool</h1>
        <p className="text-lg mt-4 max-w-2xl">
          A place where education meets excellence. Enroll now and start your
          journey!
        </p>
        <button
            onClick={() => window.location.replace("joinus.php")}
            className=" lg:inline-flex items-center border-0 py-2 px-5 focus:outline-none rounded-full bg-primary text-white focus:ring-2 hover:scale-105 transition duration-300"
          >
            {t("joinus")}
          </button>
      </div>
    </div>
  );
};

export default Test;
